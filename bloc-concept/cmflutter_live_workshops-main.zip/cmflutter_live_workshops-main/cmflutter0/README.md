# remove comments

- //.\*

# flutter plugins

- flutter enhancement suite
- flutter assets auto completion

# github

- https://github.com/codemobiles/cmflutter_live_workshops

# test url

- https://codemobiles.com/adhoc/youtubes/index_new.php?username=admin&password=password&type=songs
