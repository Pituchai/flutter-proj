package com.codemobiles.live.flutter.cm01.cmflutter0

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
