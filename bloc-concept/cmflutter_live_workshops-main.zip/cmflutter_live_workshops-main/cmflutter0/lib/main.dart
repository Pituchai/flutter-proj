import 'package:cmflutter0/src/app.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(const CMApp());
}

