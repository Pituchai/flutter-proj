# flutter development preparation

- https://github.com/codemobiles/cm-prepare-dev-tools-full-stack/blob/main/flutter.txt
- https://chrome.google.com/webstore/detail/octotree-github-code-tree/bkhaagjahfmjljalopjnoealnfndnagc
- https://developer.android.com/studio
- https://docs.flutter.dev/get-started/install
