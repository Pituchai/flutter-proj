package com.example.layout1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
