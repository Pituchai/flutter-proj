class Profile {
  String name;
  String stID;
  String email;

  Profile({
    required this.name,
    required this.stID,
    required this.email,
  });
}
